package com.hospital.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.hospital.exception.ApplicationException;
import com.hospital.model.AdminPojo;
import com.hospital.model.PhysicianPojo;
import com.hospital.service.RegisterService;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { TestBeanConfig.class })
public class RegisterTest {

	AdminPojo adminPojo = new AdminPojo();
	PhysicianPojo physicianPojo = new PhysicianPojo();
	@Autowired
	public RegisterService registerService;

	// valid username and password for Admin
	@Test
	public void testAdminLogin() throws ApplicationException {
		adminPojo.setAdminId("ADM044");
		adminPojo.setPassword("11");
		int login = registerService.adminLogin(adminPojo);

		assertEquals(1, login);

	}

	@Test
	public void testAdminLogin1() throws ApplicationException {
		adminPojo.setAdminId("ADM044");
		adminPojo.setPassword("1178676");
		int login = registerService.adminLogin(adminPojo);

		assertEquals(0, login);

	}

	@Test
	public void testAdminLogin2() throws ApplicationException {
		adminPojo.setAdminId("ADM077");
		adminPojo.setPassword("67868");
		int login = registerService.adminLogin(adminPojo);

		assertEquals(-1, login);

	}

	// getting the username for session
	@Test
	public void testgetAdminName() throws ApplicationException {
		adminPojo.setAdminId("ADM044");
		String name = registerService.getAdminName(adminPojo.getAdminId());

		assertEquals("Roja", name);

	}

	// valid username and password for Physician
	@Test
	public void testPhysicianLogin() throws ApplicationException {
		physicianPojo.setPhysicianId("PHY022");
		physicianPojo.setPassword("23");
		int login = registerService.physicianLogin(physicianPojo);

		assertEquals(1, login);

	}

	@Test
	public void testPhysicianLogin1() throws ApplicationException {
		physicianPojo.setPhysicianId("PHY022");
		physicianPojo.setPassword("2345");
		int login = registerService.physicianLogin(physicianPojo);

		assertEquals(0, login);

	}

	@Test
	public void testPhysicianLogin2() throws ApplicationException {
		physicianPojo.setPhysicianId("PHY02289");
		physicianPojo.setPassword("2873");
		int login = registerService.physicianLogin(physicianPojo);
		assertEquals(-1, login);

	}

	// getting the username for session
	@Test
	public void testgetPhysicianName() throws ApplicationException {
		physicianPojo.setPhysicianId("PHY022");
		String name = registerService.getPhysicianName(physicianPojo.getPhysicianId());

		assertEquals("Divya", name);

	}
}
