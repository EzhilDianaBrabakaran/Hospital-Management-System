package com.hospital.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.hospital.exception.ApplicationException;
import com.hospital.model.PatientPojo;
import com.hospital.service.PatientService;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { TestBeanConfig.class })
public class PatientTest {
	List list1 = new ArrayList();
	List list2 = new ArrayList();
	@Autowired
	PatientService patientService;
	PatientPojo patientPojo2 = new PatientPojo();

	@Test
	public void fetchPatient() throws ApplicationException {
		PatientPojo patientPojo1 = new PatientPojo("PAT016", "Rani", "V", 8, "Female", "12-1-11", "rani@gmail.com",
				"11", "sipcot", "siruseri", "chennai", "Tamilnadu", 603103, 0L, 9874563210L);
		PatientPojo patientPojo2 = new PatientPojo("PAT017", "Raj", "S", 20, "Male", "20/02/1999", "raj@gmail.com",
				"1212", "V.O.C Street", "Padur", "Chennai", "Tamilnadu", 603130, 633333L, 693258452L);
		PatientPojo patientPojo3 = new PatientPojo("PAT019", "Harsha", "M", 20, "Female", "20/10/1999",
				"harsha@gmail.com", "11", "V.O.C Street", "Tambaram", "Chennai", "TamilNadu", 633322, 963258745L,
				963258741L);
		PatientPojo patientPojo4 = new PatientPojo("PAT021", "Charan", "c", 12, "Male", "12/05/2007",
				"charan@gmail.com", "1212", "Kamarajar Nagar", "Egmore", "Chennai", "TamilNadu", 632555, 963258741L,
				963258741L);
		PatientPojo patientPojo5 = new PatientPojo("PAT023", "Jai", "L", 30, "Male", "12/03/1989", "jai@gmail.com",
				"111", "North street", "Egmore", "Chennai", "TamilNadu", 632589, 2365987415L, 6333656565L);
		PatientPojo patientPojo6 = new PatientPojo("PAT025", "Harini", "D", 23, "Gender", "12-1-12", "harini@gmail.com",
				"12", "West Street", "Tambaram", "Chennai", "TamilNadu", 632102, 121L, 6985231470L);
		PatientPojo patientPojo7 = new PatientPojo("PAT026", "Hima", "S", 21, "Female", "12/12/1997", "hima@gmail.com",
				"111111111111111", "V.O.C street", "Tambaram", "Chennai", "TamilNadu", 632510, 0L, 9865321470L);
		PatientPojo patientPojo8 = new PatientPojo("PAT029", "test", "S", 25, "Female", "04/10/2008", "abc@gmail.com",
				"test", "test", "test", "Chennai", "Tamil Nadu", 603103, 4564564564L, 1231231231L);
		PatientPojo patientPojo9 = new PatientPojo("PAT030", "Jeevitha", "s", 4, "Female", "05/14/2015",
				"jeevitha@gmail.com", "11", "Kamaraj Nagar", "Aavadi", "Chennai", "Tamil Nadu", 632541, 9632587410L,
				9874563211L);
		PatientPojo patientPojo10 = new PatientPojo("PAT032", "Anbu", "S", 3, "Male", "06/05/2018", "anbu@gmail.com",
				"11", "Nehru Street", "Tambaram", "Chennai", "Tamil Nadu", 600043, 9855766334L, 9087564356L);
		PatientPojo patientPojo11 = new PatientPojo("PAT033", "Vasu", "P", 4, "Male", "06/13/2015", "vasu@gmail.com",
				"22", "North Road", "Vandaloor", "Chennai", "Tamil Nadu", 600087, 0L, 9876543456L);
		PatientPojo patientPojo12 = new PatientPojo("PAT034", "Suresh", "V", 5, "Male", "06/04/2014",
				"suresh@gmail.com", "1111", "Nehru Nagar", "Main road", "Chennai", "Tamil Nadu", 600043, 0L,
				9876567894L);
		list1.add(patientPojo1);
		list1.add(patientPojo2);
		list1.add(patientPojo3);
		list1.add(patientPojo4);
		list1.add(patientPojo5);
		list1.add(patientPojo6);
		list1.add(patientPojo7);
		list1.add(patientPojo8);
		list1.add(patientPojo9);
		list1.add(patientPojo10);
		list1.add(patientPojo11);
		list1.add(patientPojo12);
		try {
			list2 = patientService.fetchPatient();
		} catch (AssertionError ae) {
			assertEquals(list1, list2);
		}

	}

	@Test
	public void fetchPatientUpdate() throws ApplicationException {
		PatientPojo patientPojo1 = new PatientPojo("PAT016", "Rani", "V", 8, "Female", "12-1-11", "rani@gmail.com",
				"11", "sipcot", "siruseri", "chennai", "Tamilnadu", 603103, 0L, 9874563210L);
		try {
			patientPojo2 = patientService.fetchPatientUpdate("PAT016");
		} catch (AssertionError ae) {
			assertEquals(patientPojo1, patientPojo2);
		}
	}

}
