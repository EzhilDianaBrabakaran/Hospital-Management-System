package com.hospital.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.hospital.entity.DiagnosisValueEntity;
import com.hospital.exception.ApplicationException;
import com.hospital.model.DiagnosisPojo;
import com.hospital.service.DiagnosisService;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { TestBeanConfig.class })
public class DiagnosisTest {
	@Autowired
	DiagnosisService diagnosisService;

	ArrayList list1 = new ArrayList();
	ArrayList list2 = new ArrayList();

	@Test
	public void testFetchValueDiagnosis() throws ApplicationException {
		DiagnosisValueEntity valueEntity1 = new DiagnosisValueEntity("Thyroid", "0.4-4 mlu/L");
		DiagnosisValueEntity valueEntity2 = new DiagnosisValueEntity("Respiration", "12-20 breath/min");
		DiagnosisValueEntity valueEntity3 = new DiagnosisValueEntity("cardiacOutput", "4-8 L/min");
		DiagnosisValueEntity valueEntity4 = new DiagnosisValueEntity("HeartRate", "60-100 beats/min");
		DiagnosisValueEntity valueEntity5 = new DiagnosisValueEntity("BloodPressure", "90-140 mmHg");
		DiagnosisValueEntity valueEntity6 = new DiagnosisValueEntity("Fever", "98.6 F");
		DiagnosisValueEntity valueEntity7 = new DiagnosisValueEntity("SugarLevel", "<100 mg/dL");
		list1.add(valueEntity1);
		list1.add(valueEntity2);
		list1.add(valueEntity3);
		list1.add(valueEntity4);
		list1.add(valueEntity5);
		list1.add(valueEntity6);
		list1.add(valueEntity7);

		try {
			list2 = diagnosisService.fetchValueDiagnosis();
		} catch (AssertionError ae) {
			assertEquals(list1, list2);
		}
	}

	@Test
	public void testFetchDiagnosisDetails() throws ApplicationException {
		DiagnosisPojo diagnosisPojo1 = new DiagnosisPojo("REP048", "PAT019", "PHY022", "06/18/2019", "06/25/2019",
				103.0, "Fever -98.6 F", 2.0, "Thyroid -0.4-4 mlu/L", 0.0, " ", 0.0, " ", 0.0, " ", 0.0, " ",
				"All fine...", " ", "Paracetamol ", "none ", " ", " ", " ", " ");
		DiagnosisPojo diagnosisPojo2 = new DiagnosisPojo("REP049", "PAT034", "PHY021", "06/17/2019", "06/20/2019", 56.0,
				"HeartRate -60-100 beats/min", 106.0, "Fever -98.6 F ", 0.0, " ", 0.0, " ", 0.0, " ", 0.0, " ",
				"Take care", " ", "Metoprolol", "Aspirin", " ", " ", " ", " ");
		DiagnosisPojo diagnosisPojo3 = new DiagnosisPojo("REP050", "PAT016", "PHY020", "06/09/2019", "06/10/2019",
				150.0, "BloodPressure -90-140 mmHg", 0.7, "Thyroid -0.4-4 mlu/L", 120.0, "SugarLevel -<100 mg/dL ", 0.0,
				" ", 0.0, " ", 0.0, " ", "Take medicines", " ", "Fludrocortisone", "Not Required", "Metformin", " ",
				" ", " ");

		DiagnosisPojo diagnosisPojo4 = new DiagnosisPojo("REP051", "PAT017", "PHY016", "06/09/2019", "06/18/2019", 8.0,
				"Thyroid -0.4-4 mlu/L", 0.0, " ", 0.0, " ", 0.0, " ", 0.0, " ", 0.0, " ", "Take Medicine regularly",
				" ", "Leno-T'", " ", " ", " ", " ", " ");
		DiagnosisPojo diagnosisPojo5 = new DiagnosisPojo("REP052", "PAT021", "PHY016", "06/24/2019", "06/25/2019", 13.0,
				"Respiration -12-20 breath/min", 0.0, " ", 0.0, " ", 0.0, " ", 0.0, " ", 0.0, " ", "All fine", " ",
				"None", " ", " ", " ", " ", " ");

		DiagnosisPojo diagnosisPojo6 = new DiagnosisPojo("REP053", "PAT034", "PHY022", "06/03/2019", "06/13/2019", 45.0,
				"Respiration -12-20 breath/min", 0.0, " ", 0.0, " ", 0.0, " ", 0.0, " ", 0.0, " ",
				"Take prescribed medicine", " ", "Azithromycin", " ", " ", " ", " ", " ");

		DiagnosisPojo diagnosisPojo7 = new DiagnosisPojo("REP056", "PAT021", "PHY022", "06/13/2019", "06/18/2019", 8.0,
				"cardiacOutput -4-8 L/min", 0.0, " ", 0.0, " ", 0.0, " ", 0.0, " ", 0.0, " ", "No comments", " ",
				"Not Required", " ", " ", " ", " ", " ");
		DiagnosisPojo diagnosisPojo8 = new DiagnosisPojo("REP057", "PAT016", "PHY021", "06/10/2019", "06/20/2019", 90.0,
				"SugarLevel -<100 mg/dL", 0.0, " ", 0.0, " ", 0.0, " ", 0.0, " ", 0.0, " ", "All fine...", " ", "None",
				" ", " ", " ", " ", " ");

		list1.add(diagnosisPojo1);
		list1.add(diagnosisPojo2);
		list1.add(diagnosisPojo3);
		list1.add(diagnosisPojo4);
		list1.add(diagnosisPojo5);
		list1.add(diagnosisPojo6);
		list1.add(diagnosisPojo7);
		list1.add(diagnosisPojo8);
		try {
			list2 = diagnosisService.fetchDiagnosisDetails();
		} catch (AssertionError ae) {
			assertEquals(list1, list2);
		}
	}

	@Test
	public void testFetchDiagnosisDetailsPhysician() throws ApplicationException {
		String physicianId = "PHY022";
		DiagnosisPojo diagnosisPojo1 = new DiagnosisPojo("REP048", "PAT019", "PHY022", "06/18/2019", "06/25/2019",
				103.0, "Fever -98.6 F", 2.0, "Thyroid -0.4-4 mlu/L", 0.0, " ", 0.0, " ", 0.0, " ", 0.0, " ",
				"All fine...", " ", "Paracetamol ", "none ", " ", " ", " ", " ");

		DiagnosisPojo diagnosisPojo2 = new DiagnosisPojo("REP053", "PAT034", "PHY022", "06/03/2019", "06/13/2019", 45.0,
				"Respiration -12-20 breath/min", 0.0, " ", 0.0, " ", 0.0, " ", 0.0, " ", 0.0, " ",
				"Take prescribed medicine", " ", "Azithromycin", " ", " ", " ", " ", " ");

		DiagnosisPojo diagnosisPojo3 = new DiagnosisPojo("REP056", "PAT021", "PHY022", "06/13/2019", "06/18/2019", 8.0,
				"cardiacOutput -4-8 L/min", 0.0, " ", 0.0, " ", 0.0, " ", 0.0, " ", 0.0, " ", "No comments", " ",
				"Not Required", " ", " ", " ", " ", " ");

		list1.add(diagnosisPojo1);
		list1.add(diagnosisPojo2);
		list1.add(diagnosisPojo3);

		try {
			list2 = diagnosisService.fetchDiagnosisDetailsPhysician(physicianId);
		} catch (AssertionError ae) {
			assertEquals(list1, list2);
		}
	}

	@Test
	public void testFetchDiagnosisUpdate() throws ApplicationException {
		String reportId = "REP048";
		DiagnosisPojo diagnosisPojo1 = new DiagnosisPojo("REP048", "PAT019", "PHY022", "06/18/2019", "06/25/2019",
				103.0, "Fever -98.6 F", 2.0, "Thyroid -0.4-4 mlu/L", 0.0, " ", 0.0, " ", 0.0, " ", 0.0, " ",
				"All fine...", " ", "Paracetamol ", "none ", " ", " ", " ", " ");

		DiagnosisPojo diagnosisPojo2 = new DiagnosisPojo();

		try {
			diagnosisPojo2 = diagnosisService.fetchDiagnosisUpdate(reportId);
		} catch (AssertionError ae) {
			assertEquals(diagnosisPojo1, diagnosisPojo2);
		}
	}

}
