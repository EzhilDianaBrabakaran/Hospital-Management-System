package com.hospital.test;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = "com.hospital")
public class TestBeanConfig {

}
