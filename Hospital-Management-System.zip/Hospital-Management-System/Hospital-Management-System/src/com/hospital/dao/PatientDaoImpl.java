package com.hospital.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Transaction;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.hospital.entity.PatientEntity;

import com.hospital.exception.ApplicationException;
import com.hospital.model.PatientPojo;

@Repository("patientDao")
public class PatientDaoImpl implements PatientDao {

	// addPatient method is used to insert patient insert into database
	@Override
	public String registerPatient(PatientPojo patientPojo) throws ApplicationException {
		String patientId = null;
		String name = null;
		SessionFactory sessionFactory8 = null;
		Session session8 = null;
		Transaction transaction8 = null;
		try {
			sessionFactory8 = HibernateUtil.getSessionFactory();
			session8 = sessionFactory8.openSession();
			transaction8 = session8.beginTransaction();
			PatientEntity patientEntity = new PatientEntity();
			patientEntity = PatientDaoImpl.patientEntityMethod(patientPojo, patientEntity);

			name = patientEntity.getFirstName();
			session8.save(patientEntity);
			transaction8.commit();

			Query query = session8.createQuery("from PatientEntity where first_name='" + name + "'");
			List<PatientEntity> list = query.list();
			for (PatientEntity entity : list) {
				patientId = entity.getPatientId();
			}

		} catch (HibernateException he8) {
			ApplicationException ae8 = new ApplicationException(he8.getMessage());
			throw ae8;
		} finally {
			session8.close();
		}

		return patientId;
	}

	// fetchPatient method will fetch all patient details
	@Override
	public ArrayList fetchPatient() throws ApplicationException {
		SessionFactory sessionFactory9 = null;
		Session session9 = null;

		ArrayList patientDetails = new ArrayList();
		try {
			sessionFactory9 = HibernateUtil.getSessionFactory();
			session9 = sessionFactory9.openSession();
			List list = session9.createQuery("from PatientEntity").list();
			for (int i = 0; i < list.size(); i++) {
				PatientEntity patientEntity = (PatientEntity) list.get(i);
				PatientPojo patientPojo = new PatientPojo();
				patientPojo.setPatientId(patientEntity.getPatientId());
				patientPojo = PatientDaoImpl.patientPojoMethod(patientPojo, patientEntity);

				patientDetails.add(patientPojo);
			}

		} catch (HibernateException he9) {
			ApplicationException ae9 = new ApplicationException(he9.getMessage());
			throw ae9;

		} finally {
			session9.close();
		}
		return patientDetails;
	}

	// By calling updatePatient method ,admin can able to update the details of
	// existing patient
	@Override
	public void updatePatient(PatientPojo patientPojo) throws ApplicationException {
		SessionFactory sessionFactory10 = null;
		Session session10 = null;
		// Transaction transaction10 = null;
		try {
			sessionFactory10 = HibernateUtil.getSessionFactory();
			session10 = sessionFactory10.openSession();
			// transaction10 = session10.beginTransaction();
			PatientEntity patientEntity = session10.get(PatientEntity.class, patientPojo.getPatientId());
			patientEntity = PatientDaoImpl.patientEntityMethod(patientPojo, patientEntity);

			session10.getTransaction().commit();

		} catch (HibernateException he10) {
			ApplicationException ae10 = new ApplicationException(he10.getMessage());
			throw ae10;

		} finally {
			session10.close();
		}

	}

	// fetchPateintUpdateMethod is used to pass the value to updation form
	@Override
	public PatientPojo fetchPatientUpdate(String patientId) throws ApplicationException {
		PatientPojo patientPojo = new PatientPojo();
		SessionFactory sessionFactory11 = null;
		Session session11 = null;

		try {
			sessionFactory11 = HibernateUtil.getSessionFactory();
			session11 = sessionFactory11.openSession();
			PatientEntity patientEntity = new PatientEntity();
			patientEntity = session11.get(PatientEntity.class, patientId);
			patientPojo.setPatientId(patientId);
			patientPojo = PatientDaoImpl.patientPojoMethod(patientPojo, patientEntity);

		} catch (HibernateException he11) {
			ApplicationException ae11 = new ApplicationException(he11.getMessage());
			throw ae11;
		} finally {
			session11.close();
		}
		return patientPojo;
	}

	static PatientPojo patientPojoMethod(PatientPojo patientPojo, PatientEntity patientEntity) {
		patientPojo.setAddressLine1(patientEntity.getAddressLine1());
		patientPojo.setAddressLine2(patientEntity.getAddressLine2());
		patientPojo.setAge(patientEntity.getAge());
		patientPojo.setAlternatePhone(patientEntity.getAlternateContact());
		patientPojo.setCity(patientEntity.getCity());

		patientPojo.setPhone(patientEntity.getContactNumber());
		patientPojo.setDateOfBirth(patientEntity.getDob());
		patientPojo.setEmailId(patientEntity.getEmail());
		patientPojo.setFirstName(patientEntity.getFirstName());
		patientPojo.setGender(patientEntity.getGender());
		patientPojo.setLastName(patientEntity.getLastName());
		patientPojo.setState(patientEntity.getState());
		patientPojo.setZipCode(patientEntity.getZipCode());
		return patientPojo;
	}

	static PatientEntity patientEntityMethod(PatientPojo patientPojo, PatientEntity patientEntity) {
		patientEntity.setFirstName(patientPojo.getFirstName());
		patientEntity.setLastName(patientPojo.getLastName());
		patientEntity.setAge(patientPojo.getAge());
		patientEntity.setAddressLine1(patientPojo.getAddressLine1());
		patientEntity.setAddressLine2(patientPojo.getAddressLine2());
		patientEntity.setCity(patientPojo.getCity());
		patientEntity.setContactNumber(patientPojo.getPhone());

		patientEntity.setAlternateContact(patientPojo.getAlternatePhone());

		patientEntity.setDob(patientPojo.getDateOfBirth());
		patientEntity.setEmail(patientPojo.getEmailId());
		patientEntity.setGender(patientPojo.getGender());
		patientEntity.setState(patientPojo.getState());
		patientEntity.setZipCode(patientPojo.getZipCode());
		return patientEntity;
	}

}
