package com.hospital.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import org.springframework.stereotype.Repository;

import com.hospital.entity.DiagnosisEntity;
import com.hospital.entity.PatientEntity;
import com.hospital.exception.ApplicationException;
import com.hospital.model.DiagnosisPojo;

@Repository("patientHistoryDao")
public class PatientHistoryDaoImpl implements PatientHistoryDao {

	// fetchPatientHistory method is used to fetch the particular patient history
	@Override
	public ArrayList fetchPatientHistory(String patientId) throws ApplicationException {
		SessionFactory sessionFactory12 = null;
		Session session12 = null;

		ArrayList patientHistoryDetails = new ArrayList();
		try {
			sessionFactory12 = HibernateUtil.getSessionFactory();
			session12 = sessionFactory12.openSession();
			List list = session12.createQuery("from DiagnosisEntity where patient_id='" + patientId + "'").list();
			List list1 = session12.createQuery("from PatientEntity where patient_id= '" + patientId + "'").list();
			String patientName = null;
			for (int j = 0; j < list1.size(); j++) {
				PatientEntity patientEntity = (PatientEntity) list1.get(j);
				patientName = patientEntity.getFirstName();

			}
			for (int k = 0; k < list.size(); k++) {
				DiagnosisEntity diagnosisEntity = (DiagnosisEntity) list.get(k);
				DiagnosisPojo diagnosisPojo = new DiagnosisPojo();
				diagnosisPojo.setPatientId(patientId);
				diagnosisPojo.setPhysicianId(diagnosisEntity.getPhysicianEntity().getPhysicianId());
				diagnosisPojo.setPatientName(patientName);
				diagnosisPojo.setPhysicianName(diagnosisEntity.getPhysicianEntity().getFirstName());
				diagnosisPojo.setTestResultDate(diagnosisEntity.getTestResultDate());
				diagnosisPojo.setServiceDate(diagnosisEntity.getServiceDate());
				diagnosisPojo.setNormalValue1(diagnosisEntity.getNormalValue1());
				diagnosisPojo.setActualValue1(diagnosisEntity.getActualValue1());
				if (diagnosisEntity.getNormalValue2() != null) {
					diagnosisPojo.setNormalValue2(diagnosisEntity.getNormalValue2());
				}
				if (diagnosisEntity.getActualValue2() != 0) {
					diagnosisPojo.setActualValue2(diagnosisEntity.getActualValue2());
				}
				if (diagnosisEntity.getNormalValue3() != null) {
					diagnosisPojo.setNormalValue3(diagnosisEntity.getNormalValue3());
				}
				if (diagnosisEntity.getActualValue3() != 0) {
					diagnosisPojo.setActualValue3(diagnosisEntity.getActualValue3());
				}
				if (diagnosisEntity.getNormalValue4() != null) {
					diagnosisPojo.setNormalValue4(diagnosisEntity.getNormalValue4());
				}
				if (diagnosisEntity.getActualValue4() != 0) {
					diagnosisPojo.setActualValue4(diagnosisEntity.getActualValue4());
				}
				if (diagnosisEntity.getNormalValue5() != null) {
					diagnosisPojo.setNormalValue5(diagnosisEntity.getNormalValue5());
				}

				if (diagnosisEntity.getActualValue5() != 0) {
					diagnosisPojo.setActualValue5(diagnosisEntity.getActualValue5());
				}
				if (diagnosisEntity.getNormalValue6() != null) {
					diagnosisPojo.setNormalValue6(diagnosisEntity.getNormalValue6());
				}
				if (diagnosisEntity.getActualValue6() != 0) {
					diagnosisPojo.setActualValue6(diagnosisEntity.getActualValue6());
				}
				diagnosisPojo.setMedicine1(diagnosisEntity.getMedicine1());
				diagnosisPojo.setMedicine2(diagnosisEntity.getMedicine2());
				diagnosisPojo.setMedicine3(diagnosisEntity.getMedicine3());
				diagnosisPojo.setMedicine4(diagnosisEntity.getMedicine4());
				diagnosisPojo.setMedicine5(diagnosisEntity.getMedicine5());
				diagnosisPojo.setMedicine6(diagnosisEntity.getMedicine6());
				patientHistoryDetails.add(diagnosisPojo);

			}

		} catch (HibernateException he12) {
			ApplicationException ae12 = new ApplicationException(he12.getMessage());
			throw ae12;

		} finally {
			session12.close();
		}
		return patientHistoryDetails;
	}

}
