package com.hospital.controller;

import java.util.ArrayList;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hospital.exception.ApplicationException;
import com.hospital.model.AdminPojo;
import com.hospital.model.PatientPojo;

import com.hospital.service.PatientService;

@Controller
public class PatientController {
	static final Logger LOG = Logger.getLogger("HospitalManagement");
	@Autowired
	public PatientService addService;

	@RequestMapping("/patientFetch")
	public ModelAndView patientFetch(HttpServletRequest request, HttpSession session, ModelMap map21) {
		ModelAndView mav21 = null;
		// session = request.getSession();
		if (session.getAttribute("name") == null) {
			map21.addAttribute("session", "session");
			map21.addAttribute("register", new AdminPojo());
			mav21 = new ModelAndView("Home");
			return mav21;
		} else {

			ArrayList patientDetails = null;
			try {
				patientDetails = addService.fetchPatient();
			} catch (ApplicationException ae21) {
				LOG.info(ae21.getMessage());
				mav21 = new ModelAndView("ApplicationError");
				return mav21;
			}

			map21.addAttribute("patientDetails", patientDetails);
			mav21 = new ModelAndView("PatientFetch");
			return mav21;
		}

	}

	@RequestMapping("/patientUpdate")
	public ModelAndView patientUpdation(@RequestParam("id") String patientId, ModelMap map22,
			HttpServletRequest request, HttpSession session) {
		ModelAndView mav22 = null;
		if (session.getAttribute("name") == null) {
			map22.addAttribute("session", "session");
			map22.addAttribute("register", new AdminPojo());
			mav22 = new ModelAndView("Home");
			return mav22;
		} else {

			PatientPojo patientPojo = null;

			try {
				patientPojo = addService.fetchPatientUpdate(patientId);
			} catch (ApplicationException ae22) {
				LOG.info(ae22.getMessage());
				mav22 = new ModelAndView("ApplicationError");
				return mav22;
			}

			map22.addAttribute("patient", new PatientPojo());
			map22.addAttribute("update", patientPojo);
			mav22 = new ModelAndView("PatientUpdate");
			return mav22;
		}
	}

	@RequestMapping(value = "/updatePatient", method = RequestMethod.POST)
	public ModelAndView updatePatient(HttpServletRequest request, ModelMap map23, HttpSession session,
			@Valid @ModelAttribute("patient") PatientPojo patientPojo, BindingResult result)
			throws ApplicationException {
		// session = request.getSession();
		ModelAndView mav23 = null;
		if (session.getAttribute("name") == null) {

			map23.addAttribute("session", "session");
			map23.addAttribute("register", new AdminPojo());
			mav23 = new ModelAndView("Home");
			return mav23;
		} else {

			String patientId = patientPojo.getPatientId();
			if (result.hasErrors()) {
				PatientPojo patientPojo1 = new PatientPojo();
				patientPojo1 = addService.fetchPatientUpdate(patientId);
				map23.addAttribute("update", patientPojo1);
				mav23 = new ModelAndView("PatientUpdate");
				return mav23;
			}
			ArrayList patientDetails = null;
			try {
				addService.updatePatient(patientPojo);
				patientDetails = addService.fetchPatient();
			} catch (ApplicationException ae23) {
				LOG.info(ae23.getMessage());
				mav23 = new ModelAndView("ApplicationError");
				return mav23;
			}

			map23.addAttribute("patientDetails", patientDetails);
			map23.addAttribute("patientId", patientPojo.getPatientId());
			map23.addAttribute("update", "update");
			mav23 = new ModelAndView("PatientFetch");
			return mav23;
		}
	}

	@RequestMapping("/registerPatient")
	public ModelAndView registerPatient(ModelMap map24, HttpSession session) {
		ModelAndView mav24 = null;
		if (session.getAttribute("name") == null) {
			map24.addAttribute("session", "session");
			map24.addAttribute("register", new AdminPojo());
			mav24 = new ModelAndView("Home");
			return mav24;
		} else {

			map24.addAttribute("patient", new PatientPojo());
			mav24 = new ModelAndView("AddPatient");
			return mav24;
		}
	}

	@RequestMapping(value = "/patientRegistration", method = RequestMethod.POST)
	public ModelAndView patientRegistration(HttpServletRequest request, ModelMap map25,
			@Valid @ModelAttribute("patient") PatientPojo patientPojo, BindingResult result, HttpSession session) {
		ModelAndView mav25 = null;
		String patientId = null;
		ArrayList patientDetails = null;
		if (session.getAttribute("name") == null) {
			map25.addAttribute("session", "session");
			map25.addAttribute("register", new AdminPojo());
			mav25 = new ModelAndView("Home");
			return mav25;
		} else {

			if (result.hasErrors()) {
				mav25 = new ModelAndView("AddPatient");
				return mav25;
			}
			try {
				patientId = addService.registerPatient(patientPojo);
				patientDetails = addService.fetchPatient();
			} catch (ApplicationException ae25) {
				LOG.info(ae25.getMessage());
				mav25 = new ModelAndView("ApplicationError");
				return mav25;
			}

			map25.addAttribute("patientId", patientId);
			map25.addAttribute("success", "success");

			map25.addAttribute("patientDetails", patientDetails);
			mav25 = new ModelAndView("PatientFetch");
			return mav25;
		}
	}

}
