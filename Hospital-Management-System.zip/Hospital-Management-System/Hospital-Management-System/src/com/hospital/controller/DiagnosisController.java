package com.hospital.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hospital.exception.ApplicationException;
import com.hospital.model.AdminPojo;
import com.hospital.model.DiagnosisPojo;

import com.hospital.model.PhysicianPojo;
import com.hospital.service.DiagnosisService;
import com.hospital.service.PatientService;
import com.hospital.service.PhysicianService;

@Controller
public class DiagnosisController {
	static final Logger LOG = Logger.getLogger("HospitalManagement");
	@Autowired
	PatientService patientService;
	@Autowired
	PhysicianService physicianService;
	@Autowired
	DiagnosisService diagnosisService;

	@RequestMapping("/addDiagnosis")
	public String addDiagnosis(ModelMap map26, HttpServletRequest request, HttpSession session)
			throws ApplicationException {
		if (session.getAttribute("name") == null) {
			map26.addAttribute("session", "session");
			map26.addAttribute("register", new AdminPojo());
			return "Home";
		} else {

			ArrayList patientDetails = null;
			ArrayList valueDetails = null;
			List physicianList = null;
			try {
				patientDetails = patientService.fetchPatient();
				physicianList = physicianService.fetchPhysician();
				valueDetails = diagnosisService.fetchValueDiagnosis();
			} catch (ApplicationException ae) {
				return "ApplicationError";
			}
			map26.addAttribute("patientDetails", patientDetails);
			map26.addAttribute("physicianDetails", physicianList);
			map26.addAttribute("valueDetails", valueDetails);
			map26.addAttribute("diagnosis", new DiagnosisPojo());
			return "AddDiagnosis";
		}
	}

	@RequestMapping("/diagnosisUpdate")
	public ModelAndView patientUpdation(@RequestParam("id") String reportId, ModelMap map27, HttpServletRequest request,
			HttpSession session) {
		ModelAndView mav27 = null;
		if (session.getAttribute("name") == null) {
			map27.addAttribute("session", "session");
			map27.addAttribute("register", new AdminPojo());
			mav27 = new ModelAndView("Home");
			return mav27;
		} else {

			DiagnosisPojo diagnosisPojo = null;
			ArrayList patientDetails = null;

			List physicianList = null;
			try {
				diagnosisPojo = diagnosisService.fetchDiagnosisUpdate(reportId);
				patientDetails = patientService.fetchPatient();
				physicianList = physicianService.fetchPhysician();

			} catch (ApplicationException ae27) {
				LOG.info(ae27.getMessage());
				mav27 = new ModelAndView("ApplicationError");
				return mav27;
			}
			map27.addAttribute("patientDetails", patientDetails);
			map27.addAttribute("physicianDetails", physicianList);

			map27.addAttribute("diagnosis", new DiagnosisPojo());
			map27.addAttribute("update", diagnosisPojo);
			mav27 = new ModelAndView("DiagnosisUpdate");
			return mav27;
		}
	}

	@RequestMapping("/addDiagnosisPhysician")
	public ModelAndView addDiagnosisPhysician(@RequestParam("id") String reportId, ModelMap map28,
			HttpServletRequest request, HttpSession session) {
		ModelAndView mav28 = null;
		if (session.getAttribute("name") == null) {
			map28.addAttribute("session", "session");
			map28.addAttribute("loginPhysician", new PhysicianPojo());
			mav28 = new ModelAndView("PhysicianLogin");
			return mav28;

		} else {
			DiagnosisPojo diagnosisPojo = null;

			ArrayList valueDetails = null;

			try {
				diagnosisPojo = diagnosisService.fetchDiagnosisUpdate(reportId);

				valueDetails = diagnosisService.fetchValueDiagnosis();
			} catch (ApplicationException ae28) {
				LOG.info(ae28.getMessage());
				mav28 = new ModelAndView("ApplicationError");
				return mav28;
			}

			map28.addAttribute("valueDetails", valueDetails);
			map28.addAttribute("diagnosis", new DiagnosisPojo());
			map28.addAttribute("update", diagnosisPojo);
			mav28 = new ModelAndView("PhysicianAddDiagnosis");
			return mav28;
		}
	}

	@RequestMapping("/updateDiagnosis")
	public ModelAndView updatePatient(HttpServletRequest request,
			@ModelAttribute("diagnosis") DiagnosisPojo diagnosisPojo, ModelMap map29, HttpSession session) {

		ModelAndView mav29 = null;
		if (session.getAttribute("name") == null) {
			map29.addAttribute("session", "session");
			map29.addAttribute("register", new AdminPojo());
			mav29 = new ModelAndView("Home");
			return mav29;
		} else {

			ArrayList diagnosisDetails = null;

			try {
				diagnosisService.updateDiagnosis(diagnosisPojo);
				diagnosisDetails = diagnosisService.fetchDiagnosisDetails();
			} catch (ApplicationException ae29) {
				LOG.info(ae29.getMessage());
				mav29 = new ModelAndView("ApplicationError");
				return mav29;
			}

			map29.addAttribute("diagnosisDetails", diagnosisDetails);
			map29.addAttribute("reportId", diagnosisPojo.getReportId());
			map29.addAttribute("update", "update");
			mav29 = new ModelAndView("DiagnosisFetch");
			return mav29;
		}
	}

	@RequestMapping("/addDiagnosisDetailsPhysician")
	public ModelAndView addDiagnosisDetailsPhysician(HttpServletRequest request,
			@Valid @ModelAttribute("diagnosis") DiagnosisPojo diagnosisPojo, BindingResult result, ModelMap map30,
			HttpSession session) throws ApplicationException {
		String physicianId = (String) session.getAttribute("physicianId");
		ModelAndView mav30 = null;
		if (session.getAttribute("name") == null) {
			map30.addAttribute("session", "session");
			map30.addAttribute("loginPhysician", new PhysicianPojo());
			mav30 = new ModelAndView("PhysicianLogin");
			return mav30;

		} else {

			ArrayList valueDetails = null;
			String reportId = diagnosisPojo.getReportId();

			if (result.hasErrors()) {
				// PhysicianPojo physicianPojo1 = new PhysicianPojo();

				DiagnosisPojo diagnosisPojo1 = diagnosisService.fetchDiagnosisUpdate(reportId);
				valueDetails = diagnosisService.fetchValueDiagnosis();

				map30.addAttribute("update", diagnosisPojo1);
				map30.addAttribute("valueDetails", valueDetails);

				mav30 = new ModelAndView("PhysicianAddDiagnosis");
				return mav30;
			}
			ArrayList diagnosisDetails = new ArrayList();
			try {
				diagnosisService.updateDiagnosis(diagnosisPojo);

				diagnosisDetails = diagnosisService.fetchDiagnosisDetailsPhysician(physicianId);
			} catch (ApplicationException ae30) {
				LOG.info(ae30.getMessage());
				mav30 = new ModelAndView("ApplicationError");
				return mav30;
			}

			map30.addAttribute("patientDetailsForPhysician", diagnosisDetails);
			map30.addAttribute("reportId", diagnosisPojo.getReportId());
			map30.addAttribute("add", "add");
			mav30 = new ModelAndView("PhysicianFetchPatient");
			return mav30;
		}
	}

	@RequestMapping("/diagnosisFetch")
	public ModelAndView patientFetch(HttpServletRequest request, HttpSession session, ModelMap map31) {
		ModelAndView mav31 = null;
		if (session.getAttribute("name") == null) {
			map31.addAttribute("register", new AdminPojo());
			mav31 = new ModelAndView("Home");
			return mav31;
		} else {

			ArrayList diagnosisDetails = null;
			try {
				diagnosisDetails = diagnosisService.fetchDiagnosisDetails();
			} catch (ApplicationException ae31) {
				LOG.info(ae31.getMessage());
				mav31 = new ModelAndView("ApplicationError");
				return mav31;
			}

			map31.addAttribute("diagnosisDetails", diagnosisDetails);
			mav31 = new ModelAndView("DiagnosisFetch");
			return mav31;
		}
	}

	@RequestMapping(value = "/addDiagnosisDetails", method = RequestMethod.POST)
	public ModelAndView addDiagnosisDetailss(HttpServletRequest request, ModelMap map32,
			@ModelAttribute("diagnosis") DiagnosisPojo diagnosisPojo, HttpSession session) {
		ModelAndView mav32 = null;
		if (session.getAttribute("name") == null) {
			map32.addAttribute("session", "session");
			mav32 = new ModelAndView("Home");
			return mav32;
		} else {

			String reportId = null;
			ArrayList diagnosisDetails = null;
			try {
				reportId = diagnosisService.registerDiagnosis(diagnosisPojo);
				diagnosisDetails = diagnosisService.fetchDiagnosisDetails();
			} catch (ApplicationException ae32) {
				LOG.info(ae32.getMessage());
				mav32 = new ModelAndView("ApplicationError");
				return mav32;
			}

			map32.addAttribute("reportId", reportId);
			map32.addAttribute("success", "success");

			map32.addAttribute("diagnosisDetails", diagnosisDetails);
			mav32 = new ModelAndView("DiagnosisFetch");
			return mav32;
		}
	}

	@RequestMapping("/diagnosisDelete")
	public ModelAndView patientDelete(@RequestParam("id") String reportId, ModelMap map33, HttpServletRequest request,
			HttpSession session) {
		ModelAndView mav33 = null;
		if (session.getAttribute("name") == null) {
			map33.addAttribute("session", "session");
			map33.addAttribute("register", new AdminPojo());
			mav33 = new ModelAndView("Home");
			return mav33;
		} else {

			ArrayList diagnosisDetails = null;
			DiagnosisPojo diagnosisPojo = new DiagnosisPojo();

			try {
				diagnosisPojo.setReportId(reportId);
				diagnosisService.deleteDiagnosis(diagnosisPojo);
				diagnosisDetails = diagnosisService.fetchDiagnosisDetails();
			} catch (ApplicationException ae33) {
				LOG.info(ae33.getMessage());
				mav33 = new ModelAndView("ApplicationError");
				return mav33;
			}

			map33.addAttribute("diagnosisDetails", diagnosisDetails);
			map33.addAttribute("reportId", diagnosisPojo.getReportId());
			map33.addAttribute("delete", "delete");
			mav33 = new ModelAndView("DiagnosisFetch");
			return mav33;
		}
	}

}
