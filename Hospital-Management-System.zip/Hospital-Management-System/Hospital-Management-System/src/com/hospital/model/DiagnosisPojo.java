package com.hospital.model;

import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

@Component("diagnosisPojo")
public class DiagnosisPojo {
	private String reportId;
	private String patientId;
	private String physicianId;
	private String serviceDate;
	private String patientName;
	private String physicianName;
	@Size(min = 1, message = "This is a required field")
	private String testResultDate;

	private String normalValue1;

	private double actualValue1;
	private String normalValue2;
	private double actualValue2;
	private String normalValue3;
	private double actualValue3;
	private String normalValue4;
	private double actualValue4;
	private String normalValue5;
	private double actualValue5;
	private String normalValue6;
	private double actualValue6;
	@Size(min = 1, message = "This is a required field")
	private String physicianComment;
	private String otherInfo;
	@Size(min = 1, message = "This is a required field")
	private String medicine1;
	private String medicine2;
	private String medicine3;
	private String medicine4;
	private String medicine5;
	private String medicine6;

	public DiagnosisPojo() {
		super();
	}

	public DiagnosisPojo(String reportId, String patientId, String physicianId, String serviceDate,
			String testResultDate, double actualValue1, String normalValue1, double actualValue2, String normalValue2,
			double actualValue3, String normalValue3, double actualValue4, String normalValue4, double actualValue5,
			String normalValue5, double actualValue6, String normalValue6, String physicianComment, String otherInfo,
			String medicine1, String medicine2, String medicine3, String medicine4, String medicine5,
			String medicine6) {
		super();

		this.patientId = patientId;
		this.otherInfo = otherInfo;
		this.testResultDate = testResultDate;
		this.physicianId = physicianId;
		this.serviceDate = serviceDate;

		this.normalValue1 = normalValue1;

		this.normalValue6 = normalValue6;

		this.physicianComment = physicianComment;

		this.medicine1 = medicine1;

		this.medicine3 = medicine3;

		this.medicine2 = medicine2;
		this.actualValue1 = actualValue1;
		this.normalValue4 = normalValue4;
		this.actualValue2 = actualValue2;
		this.medicine4 = medicine4;
		this.normalValue3 = normalValue3;
		this.reportId = reportId;
		this.actualValue5 = actualValue5;
		this.actualValue3 = actualValue3;

		this.actualValue4 = actualValue4;
		this.normalValue5 = normalValue5;

		this.medicine5 = medicine5;
		this.actualValue6 = actualValue6;
		this.medicine6 = medicine6;
		this.normalValue2 = normalValue2;
	}

	public void setReportId(String reportId) {
		this.reportId = reportId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public void setServiceDate(String serviceDate) {
		this.serviceDate = serviceDate;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public void setPhysicianName(String physicianName) {
		this.physicianName = physicianName;
	}

	public void setPhysicianId(String physicianId) {
		this.physicianId = physicianId;
	}

	public void setTestResultDate(String testResultDate) {
		this.testResultDate = testResultDate;
	}

	public void setActualValue1(double actualValue1) {
		this.actualValue1 = actualValue1;
	}

	public void setNormalValue1(String normalValue1) {
		this.normalValue1 = normalValue1;
	}

	public void setActualValue2(double actualValue2) {
		this.actualValue2 = actualValue2;
	}

	public void setPhysicianComment(String physicianComment) {
		this.physicianComment = physicianComment;
	}

	public void setNormalValue3(String normalValue3) {
		this.normalValue3 = normalValue3;
	}

	public void setActualValue3(double actualValue3) {
		this.actualValue3 = actualValue3;
	}

	public void setNormalValue4(String normalValue4) {
		this.normalValue4 = normalValue4;
	}

	public void setNormalValue5(String normalValue5) {
		this.normalValue5 = normalValue5;
	}

	public void setNormalValue2(String normalValue2) {
		this.normalValue2 = normalValue2;
	}

	public void setMedicine4(String medicine4) {
		this.medicine4 = medicine4;
	}

	public void setNormalValue6(String normalValue6) {
		this.normalValue6 = normalValue6;
	}

	public void setActualValue4(double actualValue4) {
		this.actualValue4 = actualValue4;
	}

	public void setOtherInfo(String otherInfo) {
		this.otherInfo = otherInfo;
	}

	public void setMedicine3(String medicine3) {
		this.medicine3 = medicine3;
	}

	public void setMedicine1(String medicine1) {
		this.medicine1 = medicine1;
	}

	public void setMedicine2(String medicine2) {
		this.medicine2 = medicine2;
	}

	public void setMedicine5(String medicine5) {
		this.medicine5 = medicine5;
	}

	public void setMedicine6(String medicine6) {
		this.medicine6 = medicine6;
	}

	public String getReportId() {
		return reportId;
	}

	public String getPatientId() {
		return patientId;
	}

	public String getPhysicianId() {
		return physicianId;
	}

	public void setActualValue5(double actualValue5) {
		this.actualValue5 = actualValue5;
	}

	public String getServiceDate() {
		return serviceDate;
	}

	public String getPatientName() {
		return patientName;
	}

	public String getPhysicianName() {
		return physicianName;
	}

	public String getTestResultDate() {
		return testResultDate;
	}

	public String getNormalValue1() {
		return normalValue1;
	}

	public double getActualValue1() {
		return actualValue1;
	}

	public String getNormalValue2() {
		return normalValue2;
	}

	public double getActualValue2() {
		return actualValue2;
	}

	public String getNormalValue3() {
		return normalValue3;
	}

	public String getMedicine3() {
		return medicine3;
	}

	public double getActualValue3() {
		return actualValue3;
	}

	public void setActualValue6(double actualValue6) {
		this.actualValue6 = actualValue6;
	}

	public String getNormalValue4() {
		return normalValue4;
	}

	public double getActualValue4() {
		return actualValue4;
	}

	public String getNormalValue5() {
		return normalValue5;
	}

	public double getActualValue5() {
		return actualValue5;
	}

	public String getNormalValue6() {
		return normalValue6;
	}

	public double getActualValue6() {
		return actualValue6;
	}

	public String getPhysicianComment() {
		return physicianComment;
	}

	public String getMedicine4() {
		return medicine4;
	}

	public String getOtherInfo() {
		return otherInfo;
	}

	public String getMedicine1() {
		return medicine1;
	}

	public String getMedicine5() {
		return medicine5;
	}

	public String getMedicine2() {
		return medicine2;
	}

	public String getMedicine6() {
		return medicine6;
	}

}
