package com.hospital.service;

import java.util.ArrayList;

import com.hospital.exception.ApplicationException;
import com.hospital.model.DiagnosisPojo;

public interface DiagnosisService {
	ArrayList fetchValueDiagnosis() throws ApplicationException;

	String registerDiagnosis(DiagnosisPojo diagnosisPojo) throws ApplicationException;

	ArrayList fetchDiagnosisDetails() throws ApplicationException;

	void deleteDiagnosis(DiagnosisPojo diagnosisPojo) throws ApplicationException;

	void updateDiagnosis(DiagnosisPojo diagnosisPojo) throws ApplicationException;

	DiagnosisPojo fetchDiagnosisUpdate(String reportId) throws ApplicationException;

	ArrayList fetchDiagnosisDetailsPhysician(String physicianId) throws ApplicationException;

}
