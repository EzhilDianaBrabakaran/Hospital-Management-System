package com.hospital.service;

import java.util.List;

import com.hospital.exception.ApplicationException;

import com.hospital.model.PhysicianPojo;

public interface PhysicianService {
	List fetchPhysician() throws ApplicationException;

	String addPhysician(PhysicianPojo physicianPojo) throws ApplicationException;

	void updatePhysician(PhysicianPojo physicianPojo) throws ApplicationException;

	PhysicianPojo fetchPhysicianUpdate(String physicianId) throws ApplicationException;

	List searchPhysician(String hospital, String speciality) throws ApplicationException;

}
