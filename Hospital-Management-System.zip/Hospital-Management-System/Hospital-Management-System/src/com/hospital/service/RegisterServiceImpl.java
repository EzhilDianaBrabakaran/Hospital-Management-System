package com.hospital.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hospital.dao.RegisterDao;
import com.hospital.exception.ApplicationException;
import com.hospital.model.AdminPojo;
import com.hospital.model.PhysicianPojo;

@Service("registerService")
public class RegisterServiceImpl implements RegisterService {

	@Autowired
	public RegisterDao registerDao;

	@Override
	public String registerAdmin(AdminPojo adminPojo) throws ApplicationException {
		String adminId = registerDao.registerAdmin(adminPojo);
		return adminId;
	}

	@Override
	public int adminLogin(AdminPojo adminPojo) throws ApplicationException {
		int check = registerDao.adminLogin(adminPojo);
		return check;
	}

	@Override
	public String getAdminName(String adminId) throws ApplicationException {
		String name = registerDao.getAdminName(adminId);
		return name;
	}

	@Override
	public int physicianLogin(PhysicianPojo physicianPojo) throws ApplicationException {
		int check = registerDao.physicianLogin(physicianPojo);
		return check;
	}

	@Override
	public String getPhysicianName(String physicianId) throws ApplicationException {
		String name = registerDao.getPhysicianName(physicianId);
		return name;
	}

}
