
package com.hospital.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.dao.PatientDao;

import com.hospital.exception.ApplicationException;
import com.hospital.model.PatientPojo;

@Service("patientService")
public class PatientServiceImpl implements PatientService {
	@Autowired
	public PatientDao addDao;

	@Override
	public String registerPatient(PatientPojo patientPojo) throws ApplicationException {
		String patientId = addDao.registerPatient(patientPojo);
		return patientId;
	}

	@Override
	public ArrayList fetchPatient() throws ApplicationException {
		ArrayList patientDetails = addDao.fetchPatient();
		return patientDetails;
	}

	@Override
	public void updatePatient(PatientPojo patientPojo) throws ApplicationException {
		addDao.updatePatient(patientPojo);

	}

	@Override
	public PatientPojo fetchPatientUpdate(String patientId) throws ApplicationException {
		PatientPojo patientPojo = addDao.fetchPatientUpdate(patientId);
		return patientPojo;
	}
}
