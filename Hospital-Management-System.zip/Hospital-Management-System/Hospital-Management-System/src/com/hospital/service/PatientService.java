package com.hospital.service;

import java.util.ArrayList;

import com.hospital.exception.ApplicationException;
import com.hospital.model.PatientPojo;

public interface PatientService {
	String registerPatient(PatientPojo patientPojo) throws ApplicationException;

	ArrayList fetchPatient() throws ApplicationException;

	void updatePatient(PatientPojo patientPojo) throws ApplicationException;

	PatientPojo fetchPatientUpdate(String patientId) throws ApplicationException;

}
