package com.hospital.service;

import com.hospital.exception.ApplicationException;
import com.hospital.model.AdminPojo;
import com.hospital.model.PhysicianPojo;

public interface RegisterService {

	String registerAdmin(AdminPojo adminPojo) throws ApplicationException;

	int adminLogin(AdminPojo adminPojo) throws ApplicationException;

	String getAdminName(String adminId) throws ApplicationException;

	int physicianLogin(PhysicianPojo physicianPojo) throws ApplicationException;

	String getPhysicianName(String physicianId) throws ApplicationException;
}
