package com.hospital.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "physician")
public class PhysicianEntity {

	@Id
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	@Column(name = "physician_id")
	private String physicianId;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "age")
	private Integer age;

	@Column(name = "gender")
	private String gender;

	@Column(name = "dob")
	private String dob;
	@Column(name = "first_name")
	private String firstName;

	@Column(name = "alt_contact")
	private Long alternateContact;

	@Column(name = "mail_id")
	private String email;

	@Column(name = "password")
	private String password;

	@Column(name = "address_line1")
	private String addressLine1;

	@Column(name = "address_line2")
	private String addressLine2;

	@Column(name = "state")
	private String state;

	@Column(name = "contact_number")
	private Long contactNumber;

	@Column(name = "zipcode")
	private String zipCode;

	@Column(name = "degree")
	private String degree;

	@Column(name = "speciality")
	private String speciality;

	@Column(name = "work_hours")
	private String workHours;

	@Column(name = "hospital")
	private String hospital;
	@Column(name = "city")
	private String city;

	public String getPhysicianId() {
		return physicianId;
	}

	public void setPhysicianId(String physicianId) {
		this.physicianId = physicianId;
	}

	public String getLastName() {
		return lastName;
	}

	public Integer getAge() {
		return age;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGender() {
		return gender;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public Long getAlternateContact() {
		return alternateContact;
	}

	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Long getContactNumber() {
		return contactNumber;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public String getDob() {
		return dob;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setAlternateContact(Long alternateContact) {
		this.alternateContact = alternateContact;
	}

	public String getPassword() {
		return password;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getSpeciality() {
		return speciality;
	}

	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public String getWorkHours() {
		return workHours;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getHospital() {
		return hospital;
	}

	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}

	public void setWorkHours(String workHours) {
		this.workHours = workHours;
	}

	public void setHospital(String hospital) {
		this.hospital = hospital;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

}
