package com.hospital.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "patient")
public class PatientEntity {

	@Id
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	@Column(name = "patient_id")
	private String patientId;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "gender")
	private String gender;
	@Column(name = "mail_id")
	private String email;

	@Column(name = "dob")
	private String dob;

	@Column(name = "contact_number")
	private Long contactNumber;
	@Column(name = "age")
	private Integer age;
	@Column(name = "alt_contact")
	private Long alternateContact;

	@Column(name = "password")
	private String password;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "address_line2")
	private String addressLine2;
	@Column(name = "zipcode")
	private Integer zipCode;

	@Column(name = "state")
	private String state;

	@Column(name = "city")
	private String city;
	@Column(name = "address_line1")
	private String addressLine1;

	public String getPatientId() {
		return patientId;
	}

	public String getLastName() {
		return lastName;
	}

	public Long getContactNumber() {
		return contactNumber;
	}

	public Integer getAge() {
		return age;
	}

	public String getGender() {
		return gender;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getDob() {
		return dob;
	}

	public String getEmail() {
		return email;
	}

	public String getPassword() {
		return password;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public Long getAlternateContact() {
		return alternateContact;
	}

	public String getState() {
		return state;
	}

	public Integer getZipCode() {
		return zipCode;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getCity() {
		return city;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public void setAlternateContact(Long alternateContact) {
		this.alternateContact = alternateContact;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public void setZipCode(Integer zipCode) {
		this.zipCode = zipCode;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

}
