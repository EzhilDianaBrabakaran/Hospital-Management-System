package com.hospital.exception;

public class ApplicationException extends Exception {
	int errorCode;
	String errorMessage;

	public ApplicationException(String errorMessage) {
		super();
		this.errorMessage = errorMessage;
	}

	@Override
	public String getMessage() {
		return errorCode + ":" + errorMessage;
	}

}
