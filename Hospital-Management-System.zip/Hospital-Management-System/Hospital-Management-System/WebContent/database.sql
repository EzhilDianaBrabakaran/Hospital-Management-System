create database hospital;

use hopital;

Admin Table :

create table admin_seq(admin_id int not null auto_increment primary key);


create table admin( adm_id varchar(128),
					first_name varchar(50),
					last_name varchar(50),
					age int(2),
					gender varchar(50),
					dob varchar(10),
					contact_number bigint(20),
					alt_contact bigint(20),
					mail_id varchar(50),
					password varchar(15));

				
delimiter $$
create trigger tg_admin_insert
    -> before insert on admin
    -> for each row
    -> begin
    -> insert into admin_seq values(null);
    -> set NEW.adm_id=concat('ADM',LPAD(LAST_INSERT_ID(),3,'0'));
    -> end $$
    
 insert into admin values();
 select *from admin;
    
    
Patient Table :

create table patient_seq(patient_id int not null auto_increment primary key);

create table patient( patient_id varchar(128),
					  first_name varchar(50),
					  last_name varchar(50),
					  age int(2),
					  gender varchar(50),
					  dob varchar(10),
					  contact_number bigint(20),
					  alt_contact bigint(20),mail_id varchar(50),
					  password varchar(15),
					  address_line1 varchar(100),
					  address_line varchar(100),
					  city varchar(50),
					  state varchar(50),
					  zipcode varchar(10));

delimiter $$
create trigger tg_patient_insert
    -> before insert on patient
    -> for each row
    -> begin
    -> insert into patient_seq values(null);
    -> set NEW.patient_id=concat('PAT',LPAD(LAST_INSERT_ID(),3,'0'));
    -> end $$
    
    
 insert into patient values();
 select *from patient; 
    
    
 Physician Table :   
    
 create table physician_seq(physician_id int not null auto_increment primary key);

create table physician( physician_id varchar(128),
						first_name varchar(50),
						last_name varchar(50),
						age int(2),
						gender varchar(50),
						dob varchar(10),
						contact_number bigint(20),
						alt_contact bigint(20),
						mail_id varchar(50),
						password varchar(15),
						address_line1 varchar(100),
						address_line varchar(100),
						city varchar(50),
						state varchar(50),
						zipcode varchar(10),
						degree varchar(50),
						speciality varchar(50),
						work_hours varchar(50),
						hospital varchar(50));

delimiter $$
create trigger tg_physician_insert
    -> before insert on physician
    -> for each row
    -> begin
    -> insert into physician_seq values(null);
    -> set NEW.physician_id=concat('PHY',LPAD(LAST_INSERT_ID(),3,'0'));
    -> end $$
    
    
    
 insert into physician values();
 select *from physician;    
    
 Diagnosis Table :
 
create table diagnosis_seq(report_id int not null auto_increment primary key);

create table diagnosis( Report_id varchar(128),
						Patient_id varchar(10),
						Physician_id varchar(10),
						Service_date varchar(10), 
						Test_result_date varchar(10),
						Diag1_actual double(10), 
						Diag1_normal varchar(20),
						Diag2_actual double(10), 
						Diag2_normal varchar(20),
						Diag3_actual double(10),
						Diag3_normal varchar(20),
						Diag4_actual double(10), 
						Diag4_normal varchar(20),
						Diag5_actual double(10), 
						Diag5_normal varchar(20), 
						Diag6_actual double(10), 
						Diag6_normal varchar(20),
						Physician_comments varchar(300),
						Other_info varchar(300),
						Medicine_1 varchar(50);
						Medicine_2 varchar(50);
						Medicine_3 varchar(50);
						Medicine_4 varchar(50);
						Medicine_5 varchar(50);
						Medicine_6 varchar(50);
						foreign key(Patient_id)references patient(Patient_id),
						foreign key(Physician_id)references physician(Physician_id));


delimiter $$
create trigger tg_diagnosis_insert
    -> before insert on diagnosis
    -> for each row
    -> begin
    -> insert into diagnosis_seq values(null);
    -> set NEW.Report_id=concat('REP',LPAD(LAST_INSERT_ID(),3,'0'));
    -> end $$
    
    
 insert into diagnosis values();
 select *from diagnosis;    
    
 Diagnosis Value Table :
 
 create table diagnosis_value(diagnosis varchar(50),
 						value varchar(50));
    
     
 insert into diagnosis_value values();
 select *from diagnosis_value;						