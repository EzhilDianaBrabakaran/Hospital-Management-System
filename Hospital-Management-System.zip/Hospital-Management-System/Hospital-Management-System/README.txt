
PROJECT CODE :  AJ_Project 20

PROJECT NAME :  HOSPITAL MANAGEMENT SYSTEM


TEAM MEMBERS ARE:

ROJA p        - 761069
EZHIL DIANA B - 761134
DIVYA KUMAR   - 764746


In this project, we have implemented the concepts of Java-Core, JSP, Hibernate, HTML, CSS, Bootstrap and we
have followed the Spring MVC Architecture for the creation of this entire project.

Modules of this Project :

	1.Admin Login and Registration
	
	2.Patient Registration,Retrieving and Updating
	
	3.Physician Registration,Retrieving and Updating
	
	4.Search Physician
	
	5.Diagnosis Registration ,Retrieving,deleting and Updating
	
	6.View Patient History
	
	7.Physician Login
	
	8.Physician updating patient diagnosis details
	
	
Module 1 : Admin Login and Registration

	-> As soon as the project gets started, users are redirected to the login page.
	
	-> If the user is new , then they should click 'Register' button which will be redirected the user to the 'Admin registration form'
	
	-> In the Admin registration form , user needs to fill the necessary fields to register themselves in the database.
	
	-> If the user is an existing user, they can login into the project using their valid credentials.
	
	-> After successful login, admin will be redirected to the 'Main' page, where they will have chance to explore other modules.
	
	-> If the user enters invalid credentials for login, then the error message will be displayed.
	
	-> In 'Main' page admin would be able to see the tabs on the left side.
	
	-> Initially ,'Patient List' tab will fetch all the patient details with 'Add','Update' and 'View History' button.
	
	->'Physician List' tab will fetch all the physician details with 'Add'and 'Update' button.
	
	->'Search Physician' Tab will help the admin to fetch the particular physician details through the search form . (search form will have specialty and hospital filters).
	
	-> 'Diagnosis List' tab will fetch all patient diagnosis details with 'Add','Delete' and 'Update' button.
	
	-> If the admin clicks logout button , the session should be closed and the admin will be redirected to the Home Page.



Module 2 : Patient Registration,Retrieving and Updating

	-> If the Admin clicks on 'Patient List' tab, it leads admin to the Patient Page initially fetching all present records in the Table.
	
	-> By clicking ,'Add Patient' button on the top, admin will get a form to register the patient into the database.
	
	-> If the admin click 'Add' button in that form , the patient details  get added into the table and 'Registered successfully'  message will be displayed along with patient Id.
	
	-> If the admin fails to provide any mandatory information or enters invalid values, then the error message will be displayed.
	
	-> After successful registration, it goes back to fetching all the records.
	
	-> If the admin clicks 'Update' button of the particular record from the main set of records, then the complete form is shown to the admin with existing values.
	
	-> After successful updating, 'Updated successfully' message will be displayed along with patient id and it goes back to fetching all the records.
	
	
	


Module 3 : Physician Registration,Retrieving and Updating

	-> If the Admin clicks on 'Physician List' tab, it leads admin to the Physician Page initially fetching all present records in the Table.
	
	-> By clicking ,'Add Physician' button on the top, admin will get a form to register the physician into the database.
	
	-> If the admin click 'Add' button in that form , the physician details  get added into the table and 'Registered successfully'  message will be displayed along with physician Id.
	
	-> If the admin fails to provide any mandatory information or enters invalid values, then the error message will be displayed.
	
	-> After successful registration, it goes back to fetching all the records.
	
	-> If the admin clicks 'Update' button of the particular record from the main set of records, then the complete form is shown to the admin with existing values.
	
	-> After successful updating, 'Updated successfully' message will be displayed along with physician id and it goes back to fetching all the records.
	
	
	
Module 4 : Search Physician 

	-> If the Admin clicks on 'Search Physician' tab, it leads admin to the search page which contains some filters.
	
	-> In that search page, admin needs to select hospital name and specialty from the drop down to search for particular physician.
	
	-> After selecting values , click 'Search' button. It will display the physician details who are all matching the search criteria.
	
	-> If the admin fails to choose value of any one of the field, then that field will be highlighted.
	

Module 5 : Diagnosis Registration,Retrieving and Updating

	-> If the Admin clicks on 'Diagnosis List' tab, it leads admin to the Diagnosis details Page initially fetching all present records in the Table.
	
	-> It is fetching patient is from 'Patient' table and Physician id from 'Physician' table.
	
	-> By clicking ,'Add Diagnosis Details' button on the top, admin will get a form to register the patient diagnosis details into the database.
	
	-> If the admin click 'Add' button in that form , the physician details  get added into the table and 'Registered successfully'  message will be displayed along with report Id.
	
	-> If the admin fails to provide any mandatory information or enters invalid values, then the error message will be displayed.
	
	-> After successful registration, it goes back to fetching all the records.
	
	-> If the admin clicks 'Update' button of the particular record from the main set of records, then the complete form is shown to the admin with existing values.
	
	-> In the update form , admin can't update Patient Id, Physician Id and Report Id, because these id is given as Read-Only as it is auto-generated.
	
	-> After successful updating, 'Updated successfully' message will be displayed along with report id and it goes back to fetching all the records.
	
	-> If the admin clicks 'Delete' button of the particular record from the main set of records, the diagnosis report will be deleted.
	
	-> But the patient record , physician record won't get deleted from the table if the admin deletes the report.
	
	-> After successful deleting, "Deleted successfully" message will be displayed along with 'Report Id' and it goes back to fetching all the record.
	
	
	
Module 6 : View Patient History

	-> If the Admin clicks on 'Patient List' tab, it leads admin to the Patient Page initially fetching all present records in the Table.
	
	-> By clicking 'View History' button of the particular patient , admin will get a whole report of that patient.
	
	-> Patient Id, name, Physician Id, name,Service date, Test result date , all the diagnosis name , normal and actual values of the diagnosis will get printed on that report.
	
	-> If the patient doesn't contains any diagnosis report, then 'No Report found' message will be displayed.
	
	
Module 7 : Physician Login 

	-> As soon as the project gets started, users are redirected to the login page.
	
	-> After successful login, physician will be redirected to the 'Main' page, where they will have chance to explore other modules.
	
	-> If the user enters invalid credentials for login, then the error message will be displayed.
	
	-> In 'Main' page physician would be able to see the tabs on the left side.
	
	-> Initially ,'Patient List' tab will fetch all the patient details with 'Add diagnosis details' button.
	
	-> If the physician clicks logout button , the session should be closed and the physician will be redirected to the Home Page.
	

Module 8 : Physician updating patient diagnosis details
 
	-> If the Physician clicks on 'Patient List' tab, it leads physician to the Diagnosis details Page initially fetching all present records in the Table.
	
	-> By clicking ,'Add Diagnosis Details' button on the top, physician will get a form to update the patient diagnosis details into the database.
	
	-> If the physician click 'Add' button in that form , the patient diagnosis details  get added into the table and 'Updated successfully'  message will be displayed along with report Id.
	
	-> If the physician fails to provide any mandatory information or enters invalid values, then the error message will be displayed.
	
	-> After updating successfully, it goes back to fetch all the records.
	
	
	
Following coding implementations have been done :

	-> Logging is  done by Log4j Framework 

	-> Exception Handling is done (Catching the Hibernate Exceptions and throw it as Application Exception which is a user defined Exception).
	
	-> Session Handling is done.

	
	
database.sql file contains all the queries related to this project.
	


	


	